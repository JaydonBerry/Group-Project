<?php
$sql = "SELECT name, openingtimes, id FROM pubs";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // WHILE LOOP TO DISPLAY, JB
    while($row = $result->fetch_assoc()) {
    echo "<div class='panel panel-primary'>";
    echo "<div class='panel-heading'>";
    echo $row["name"];
    echo "</div>";
    echo "<div class='panel-body'>" ;
    echo $row["openingtimes"]; 
    //DEBUG FOR ROW ARRAY, JB
    //echo $row["id"]; 
    //NESTED POST TO CARRY VARIABLES, JB
    echo "<a href='event-drinks.php?id=".$row["id"]."name=".$row["name"]."'> <button class='btn btn-lg btn primary btn-block sbt-btn' role='button'>More Info</button></a>";
    echo "</div></div>";
        
    }
} else {
    echo "0 results";
}
//DATABASE CONNECTION CLOSE, JB
$conn->close();
 
?>


<?php 
include 'dbconnect.php';
//GET POST DATA, JB
$id = $_GET['id'];
//DELETE QUERY, JB
$sql = "DELETE FROM event WHERE id=$id";
if(mysqli_query($conn, $sql)){
	//DEBUG FOR INSERT QUERY, JB
    #echo "Records added successfully.";
        header("Location: events.php");
    exit;

} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Additional information</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
  </head>
  <body>
<div class="container"
<?php
include 'dbconnect.php';
//RETRIEVE POST DATA, JB
$id=$_GET['id'];
//SQL QUERY
$sql = "SELECT name, openingtimes, id, imgurl FROM meals WHERE id = '$id'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
    //NESTED JUMBOTRON, IMAGE CHANGES BASED ON IMGURL FIELD, JB
    echo "<div class='jumbotron' style='background-image: url(".$row["imgurl"]."); background-size: cover;'></div>";
    echo "<div class='panel panel-primary'>";
    echo "<div class='panel-heading'>";
    echo $row["name"];
    echo "</div>";
    echo "<div class='panel-body'>" ;
    echo $row["openingtimes"]; 
    #echo $row["id"];
    echo "</div></div>";
    $name=$row["name"];
        
    }
} else {
    //DEBUG SQL RESULTS, JB
    echo "0 results";
}
$conn->close();
 
?>
<form action="insert.php" method"POST">
  <div class="form-group">
    <label for="EventGoers">Who's Going?</label>
    <input type="text" class="form-control" id="EventGoers" aria-describedby="emailHelp" placeholder="Enter Attendees" name="eventusers">
  </div>
  <div class="form-group">
    <label for="location">location</label>
    <input type="text" class="form-control" id="location" placeholder="" name="location" value="<?php  echo $name ?>">
  </div>
  <div class="form-group">
    <label for="date">Date</label>
    <input type="date" class="form-control" id="date" placeholder="" name="eventdate">
  </div>
    <div class="form-group">
    <label for="starttime">Start Time</label>
    <input type="time" class="form-control" id="starttime" placeholder="" name="starttime">
  </div>
    <div class="form-group">
    <label for="endtime">Finish Time</label>
    <input type="time" class="form-control" id="endtime" placeholder="" name="endtime">
  </div>
    <button type="submit" value="submit" class="btn btn-primary">Submit</button>
</form>
</div>
        
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
  </body>
</html>
<!DOCTYPE html>
<html lang="en">
  <head>
  <?php session_start() ?>
      <style>
       #map {
        height: 300px;
        width: 100%;
       }
    </style>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Events</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    </head>
  <body>
  <!-- <div class="container"> -->    
    <ul class="nav nav-pills">
  <li role="presentation"><a href="results-drinks.php">Drinks</a></li>
  <li role="presentation"><a href="results-meals.php">Meals</a></li>
  <li role="presentation"><a href="results-clubs.php">Clubs</a></li>
  <li role="presentation" class="active"><a href="events.php">Ongoing Events</a></li>
</ul>


<?php include 'dbconnect.php';
$sql = "SELECT id, users, location, starttime, endtime, eventdate FROM event";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
    echo "<div class='panel panel-primary'>";
    echo "<div class='panel-heading'>";
    echo $row["location"];
    echo "</div>";
    echo "<div class='panel-body'>" ;
    echo $row["users"]."<br>";
    echo $row["starttime"];
    echo $row["endtime"]."<br>";
    echo $row["eventdate"]."<br>";
    #echo $row["id"];
    echo "<a href='delete.php?id=".$row["id"]."'> <button class='btn btn-lg btn primary btn-block sbt-btn' role='button'>delete</button></a>";
    echo "</div></div>";
    }
} else {
    echo "0 results";
}
$conn->close();
?>


    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCm3y4YcJ0Kl9bwYK-imbD7WPFbnitX1Xg&callback=initMap">
    </script>

        
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <!-- </div> -->
  </body>
</html>
-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2017 at 03:59 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `group_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `clubs`
--

CREATE TABLE `clubs` (
  `id` int(8) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(3500) NOT NULL,
  `openingtimes` varchar(250) NOT NULL,
  `imgurl` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clubs`
--

INSERT INTO `clubs` (`id`, `name`, `description`, `openingtimes`, `imgurl`) VALUES
(1, 'Tokyo Huddersfield', 'Welcome to Tokyo Huddersfield!<br><br> We have 3 floors of music to provide our ravers with the ultimate clubbing experience.<br><br> All 3 floors feature the best of RNB and Hip Hop, House and Pop. We also have an outside with a smoking area and a bar.<br><br> Tokyo''s is the place to be if you''re wanting a decent night out in Huddersfield!', 'Wed 23:00 - 04:30<br> Fri 23:00 - 04:00<br> Sat 23:00 - 04:30<br>', 'images/Tokyos.jpg'),
(2, 'Camel Club', 'With the excellent Bar Staff, Management and Bouncers.<br><br> Camel club''s Huddersfield''s very own quirky alternative to mainstream clubbing.<br><br> We provide the biggest and best Musical Mix to suit all tastes!', 'Mon/Sat 22:30PM - 04:00PM<br>', 'images/CamelClub.jpg'),
(3, 'Mavericks 80''s Lounge', 'We offer a unique combination of a modern cocktail bar, the best of British street food and a Lounge bar that provides our customer with a spot where they can party until late.<br><br> Our Cocktail Bar comes with exquisite cocktails from around the world with a bit of an 80''s feel.<br><br> The 80''s theme kicks into action every Friday and Saturday from around 9:00 pm till late whilst our Resident DJ supplies the best sounds of the 80''s for you to party the night away!', 'Mon 22:00pm - 02:00am<br> Tues 20:00pm - 02:00am<br> Wed 17:00pm - 04:00am<br> Thurs 17:00pm - 02:00am<br> Fri/Sat 17:00pm - 04:00am<br>', 'images/Mavericks80sLounge.jpg'),
(4, 'The Rock Cafe', 'The Rock Cafe is a stylish American themed bar serving delicious food and snacks by day and a lively party atmosphere by night!', 'Mon 11:30am - 10pm<br> \r\nTues 11:30am - 7pm<br> \r\nWed 11:30am - 01:00am <br>\r\nThurs 11:30am - 00:00am <br>\r\nFri 11:30am - 02:30am <br>\r\nSat 11:00am - 02:30am <br>\r\nSun 12pm - 11pm<br>', 'images/TheRockCafe.jpg'),
(5, 'Five Bar', 'Welcome to Five Bar and Kitchen! We offer our customers the chance to relax in our atmospheric interior and sun terrace during the day and get their dancing shoes on in the evening.<br><br> Whether you''re indulging yourself with a bite to eat from our unique menu, spoiling yourself with our extensive cocktail list or simply hitting the town in style.<br><br> We ensure that you''ll enjoy the selection of spirits, lagers and bottles on offer.<br><br> Our friendly and entertaining bar staff will ensure that you''ll always feel welcome!', 'Mon/Tues/Thurs 11:30AM - 11:00PM<br> Wed/Fri/Sat 11:30AM - 04:00AM<br>', 'images/FiveBar.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `event`
--

CREATE TABLE `event` (
  `id` int(11) NOT NULL,
  `users` varchar(250) NOT NULL,
  `location` varchar(100) NOT NULL,
  `starttime` varchar(6) NOT NULL,
  `endtime` varchar(6) NOT NULL,
  `eventdate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `meals`
--

CREATE TABLE `meals` (
  `id` int(8) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` varchar(3500) NOT NULL,
  `openingtimes` varchar(100) NOT NULL,
  `imgurl` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `meals`
--

INSERT INTO `meals` (`id`, `name`, `description`, `openingtimes`, `imgurl`) VALUES
(1, 'La la''s Restaurant', 'Welcome to Lala''s Indian Restaurant!<br><br> We specialise in delicious cuisine, including house specialities and other customer favourites.<br><br> Whether you are in the mood to indulge in something new or just want to enjoy some old favourites we can almost guarantee that our inventive menu and attentive will have you leaving our restaurant truly satisfied.<br><br> Our cuisine entrees are served in a relaxed and welcoming atmosphere that you, your family and friend will surely enjoy so no matter what your occasion calls for or your appetite demands, our friendly staff will promise to make your next dining experience a pleasant one!', 'Sun/Thurs 5pm - 11:30pm<br> Fri/Sat 5pm - 12:30<br>', 'images/LalasRestaurant.jpg'),
(2, 'The Chinese Buffet', 'We are an expanding chain of restaurant across the North West and North East of England and elsewhere.<br><br> We offer customers with the very best authentic and innovative Chinese cuisine all you can eat meals at an attractive price.<br><br> All this is combined with professional, friendly and quick service in modern and stylish surroundings to offer the most enjoyable customer experience!', 'Mon/Thurs 12PM - 10PM<br> Fri/Sat 12PM - 10:30PM<br> Sun 12PM - 9:30PM<br>', 'images/TheChineseBuffet.jpg'),
(3, 'Da Sandro', 'We are renowned for our exceptional, creative and authentic Italian food, prepared and cooked by our passionate head chef, Franco Zoppi and his well trained team using only the highest quality ingredients.<br><br> We also offer an extensive menu of classic Italian favourites and a daily specials board that features fresh and seasonal meat and seafood dishes.<br><br> We take pride in our professional service and vibrant restaurant atmosphere and we always provide our customers with an experience that reflects the true taste of Italy in traditional Italian surroundings!<br><br> Buon Appetito!', 'Mon/Fri 12:30 - 22:30<br> Sat 12:00 - 22:30<br> Sun 12:30 - 21:30<br>', 'images/DaSandro.jpg'),
(4, 'Thai Sakon', 'Here at the Thai Sakon Restaurant we aim to provide our customer with the finest genuinely authenthic Thai Cuisine in relaxed and friendly surroundings.<br><br> All our dishes are prepared from the very best ingredient, including fresh herbs, spices and exotic vegetable delivered every week from growers in Thailand.<br><br> We also serve a selection of Thai wines and beers, brewed specifically to compliment the flavours of our Thai food!', 'Mon/Fri 3:30pm - 10:30pm<br> Sat 6:00pm - 11:00pm<br> Sun 6:00pm - 10:00pm<br>', 'images/ThaiSakon.jpg'),
(5, 'Med-One Lebanese Restaurant', 'Although Med One might be new to Huddersfield but our proprietor has been in the restaurant business for over 25 years!<br><br> Chef Khalil and his wife Rojin have been running restaurants in a number of  different countries including Norway, Sweden and Germany before moving to the UK. Our Chef''s passion lies with Mediterranean and Levantine dishes and cuisines.', 'Mon/Fri 17:00 - 22:00<br> Sat 12:00 - 22:00<br> Sun 17:00 - 21:00<br>', 'images/MedOne.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pubs`
--

CREATE TABLE `pubs` (
  `id` int(8) NOT NULL,
  `name` varchar(250) NOT NULL,
  `description` varchar(3500) NOT NULL,
  `openingtimes` varchar(250) NOT NULL,
  `imgurl` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `pubs`
--

INSERT INTO `pubs` (`id`, `name`, `description`, `openingtimes`, `imgurl`) VALUES
(1, 'The Grove', 'Welcome to The Grove!\r\n<br>\r\n<br>\r\nWe have a beer garden located within our Pub.\r\n<br> \r\nA tap room that contains a huge selection of beers spirits and snacks that will leave you feeling spoilt. \r\n<br>\r\nWe also have a Lounge Room where you can go to chill and spend quality time with family and friends!', 'Sun 12:00 - 23:00<br>\r\nMon/Wed 14:00 - 23:00<br>\r\nThurs 14:00 - 00:00<br>\r\nFri/Sat 12:00 - 00:00<br>', 'images/Groveinn.jpg'),
(2, 'The Sportsman', 'We speciailise in providing our customers with Real Ale, Real Food and Real Music. That''s what we''re all about!<br><br> We take pride in serving the best locally crafted ales along specialities from around the globe. <br><br>We have award winning house to provide our customers with a warm, friendly atmosphere whilst being catered to by dedicated and passionate staff members.', 'Mon/Thurs 12:00 - 23:00<br> Fri 11:00-00:00<br> Sat 12:00 - 23:00<br> Sun 11:30 - 23:00<br>', 'images/TheSportsman.jpg'),
(3, 'Rat and Ratchet', 'Welcome to Rat and Ratchet! We are Huddersfield''s very own iconic award-winning brew pub which have now been given a new lease of life.<br><br> Our Pub is filled with eye catching art and imaginative decoration which leaves our customers with an overall exceptional drinking experience.<br><br> We also have a Rat Brewery housed underneath our pub which supplies festivals and bars countrywide!', 'Mon/Thurs 3pm - Close <br>Fri/Sun 12noon - Close<br>', 'images/Rat&Ratchet.jpg'),
(4, 'Crown Hotel', 'We are a traditional local pub in Huddersfield Town Centre. <br><br>Our pub was a Hotel in its previous years but now it''s affectionately known today as "Crown" by its regulars.<br><br> The pub''s main focal point is the Bar but we also don''t disappoint in providing a welcoming atmosphere with friendly staff and a large variety of drinks for our guests to choose from.<br><br> In addition, we also have a selection of six constantly changing Guest Cask  Ale''s!', '10.00am - 12.00pm<br>', 'images/CrownHotel.jpg'),
(5, 'Yorkshire Rose', 'We offer our customers a wide range of soft drinks, lagers and cask ales making Yorkshire Rose the perfect place to visit for any occasion. <br><br>We are also a family friendly pub and have a great children''s menu with exquisite patio seating. <br><br>We are located on the A62 Leeds Road just half a mile from Huddersfield town centre so we hope to see you at the Yorkshire Rose Pub very soon!', 'Mon/Sat 09:00 - 23:00<br> Sunday 12:00- 23:00<br>', 'images/YorkshireRose.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'Jaydon', 'Letmein'),
(2, 'Prince', 'Letmein');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clubs`
--
ALTER TABLE `clubs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `event`
--
ALTER TABLE `event`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `meals`
--
ALTER TABLE `meals`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pubs`
--
ALTER TABLE `pubs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clubs`
--
ALTER TABLE `clubs`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `event`
--
ALTER TABLE `event`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `meals`
--
ALTER TABLE `meals`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pubs`
--
ALTER TABLE `pubs`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php
$xml=simplexml_load_file("drinks.xml") or die("Error: Cannot create object");
foreach($xml->children() as $drinks) { 
    echo $drinks->name . "<br><br> "; 
    echo $drinks->description . "<br><br> "; 
} 
?>
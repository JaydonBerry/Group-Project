<?php
//DATABASE CONNECTION SETTINGS! JB
$servername = "localhost";
$username = "root";
$password = "Letmeinplox1";
$dbname = "group_project";

// CREATE CONNECTION, JB
$conn = new mysqli($servername, $username, $password, $dbname);
// CHECK CONNECTION, JB
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//CONNECTION DEBUG, JB
//echo "Connected successfully";
?>
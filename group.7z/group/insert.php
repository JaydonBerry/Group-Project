<?php 
include 'dbconnect.php';
//GET POST DATA, JB
$users = $_GET['eventusers'];
$location = $_GET['location'];
$starttime = $_GET['starttime'];;
$endtime = $_GET['endtime'];
$eventdate =  $_GET['eventdate'];
//INSERT QUERY, JB
$sql = "INSERT INTO event (users, location, starttime, endtime, eventdate) VALUES ('$users', '$location', '$starttime', '$endtime', '$eventdate')";
if(mysqli_query($conn, $sql)){
	//DEBUG FOR INSERT QUERY, JB
    #echo "Records added successfully.";
        header("Location: results-drinks.php");
    exit;

} else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}

?>
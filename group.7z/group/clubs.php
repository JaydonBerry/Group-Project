<?php
$sql = "SELECT name, openingtimes, id FROM clubs";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // WHILE LOOP TO DISPLAY, JB
    while($row = $result->fetch_assoc()) {
    echo "<div class='col-md-8 col-md-offset-2 cards'>";
    echo "<div class='panel-heading card-heading'>";
    echo $row["name"];
    echo "</div>";
    echo "<div class='panel-body'>" ;
    echo $row["openingtimes"]; 
    //DEBUG FOR ROW ARRAY, JB
    //echo $row["id"]; 
    //NESTED POST TO CARRY VARIABLES, JB
    echo "<a href='event-clubs.php?id=".$row["id"]."name=".$row["name"]."'> <button class='btn btn-lg btn primary btn-block dtls-btn' role='button'>More Info</button></a>";
    echo "</div></div>"; 
    }
} else {
    echo "0 results";
}
//DATABASE CONNECTION CLOSE, JB
$conn->close();
?>
